# Deploying the postage-stamp searches on other machines

Everything needed is in `psph/` (single C file + Makefile + driver script). Copy that directory (or the
tarball `psph_deploy.tgz` in the project root) to each machine.

## Build and validate (once per machine)

```bash
cd psph
make linux            # Linux x86-64: gcc -march=native, AVX2 path; Linux aarch64 (Sparks): NEON path
# make linux LCC=clang  (to use clang);   make linux NOSIMD=1  (scalar fallback if the SIMD build misbehaves)
# macOS Apple Silicon: just  make
./psph -selftest quick     # ~4 min on 10 threads, 422 checks against the published tables; MUST print 0 failures
./psph16 -h 9 -k 5 -t 797 -j 4 -p 0   # smoke test of the 16-bit build: must print SOLUTION ... 1 9 23 108 181
```

The AVX2 path was written on the Mac and cannot be tested there, so run the selftest on the x86 box before
any production run. If it fails, rebuild with `NOSIMD=1` and run the selftest again.

## Jobs, in priority order

All runs use `run_range.sh TAG H K TGT D LO HI CHUNK THREADS [BINARY]`; the item range `[LO,HI)` is what
partitions a search across machines (item order is deterministic; the split depth D must be identical
everywhere). The final answer is the maximum `n_h` over all machines' `logs/TAG/solutions.log` once every
range is complete; every chunk is resumable (re-run the same command).

### 1. n(9,8) = A053348(9) = A005344(8)  — remainder of the overnight run

* Best known: **5521** (basis 1 3 14 46 201 346 1135 1661), found in items 800..1200. Target 5522.
* Items at depth 4: 11003. Items 0..1200 are DONE (Mac, logs/overnight). Remaining: [1200, 11003).
* Observed cost: 400 items took 50 min, 66 min and 5.4 h on 10 M1 Pro threads (the expensive region had
  a_2 = 3); expect 60-150 M1-core-hours for the remainder, i.e. roughly one to two hours on 96 cores.
* Suggested split (adjust to core counts): 96-core box items [1200, 8000), Mac Studio [8000, 11003).
  Keep CHUNK well above the thread count (a chunk ends when its slowest item ends):

```bash
./run_range.sh h9k8_box    9 8 5522 4 1200 8000  1000 96
./run_range.sh h9k8_studio 9 8 5522 4 8000 11003  600 24
```

* If a solution with n_h > 5521 appears anywhere, later chunks can be restarted with TGT = n_h + 1
  (delete nothing; just change TGT — the maximum over all solutions is still the answer).

### 2. A001209(303) = n(303,4)  — new term, needs psph16

* Lower bound **71148327** from the formula basis 1 228 17657 912312 (range verified). Target 71148328.
* Expected cost 2000-3300 core-hours (full checks dominate); ~1 day on 96 cores.
* Work items: 301 at depth 2 (one per a_2). Depth 3 would give ~3e6 items but generating them costs
  ~10 min of single-thread DP on every machine, so use depth 2; the ~100 heaviest items (a_2 between
  ~100 and ~230) each carry ~1 % of the work, which balances acceptably over 96 threads.

```bash
./run_range.sh h303k4_box 303 4 71148328 2 0 301 301 96 ./psph16     # one chunk = whole job (~1 day)
# or in two resumable halves:  ... 2 0 150 150 96 ./psph16   and   ... 2 150 301 151 96 ./psph16
```

* RAM: psph16 tables are 3 x (TGT+1) x 2 bytes = 430 MB per thread -> 41 GB at 96 threads. Fine on the
  2 TB box; use -j 48 elsewhere.

* After h=303: the same basis gives the formula values for h=304..306 (72060639, 72972951, 73885263); each
  is a separate run of similar cost.

### 3. A001211(27) = n(27,6)

* Lower bound **176380** (basis 1 19 177 1016 6649 22876, heuristic); target 176381.
* Items: 4005 at depth 3, 2,964,437 at depth 4 (generated in 2 s). Expected 300-3000 core-hours (growth
  exponent still rising at h=14), so start it only when a machine is otherwise idle; the ETA printed after
  the first chunks tells the truth. Depth 4 balances best:

```bash
./run_range.sh h27k6_box 27 6 176381 4 0 2964437 100000 96
```
* The h=26 extremal basis 1 19 177 816 6708 18060 has 27-range 174804 (a weaker but certain bound).

### 4. A001210(91) = n(91,5)

* Lower bound: the h=90 extremal basis 1 70 1412 32085 371775 has 91-range **8897042** (certain); the true
  value is probably ~9.0e6 (ratio ~1.06 per step). Target 8897043 (safe) — a better heuristic bound would
  speed the run a little. Expected 1600-8000 core-hours. Items: 133,730 at depth 3.

```bash
./run_range.sh h91k5_box 91 5 8897043 3 0 133730 5000 96
```

### Not for now
A001212(25) (4e17-8e17 nodes; needs the CUDA port and/or Challis's pruning), k=9 h=8 (~1e5 core-h),
the h=3/4/5 row proofs.

## Notes

* NITEMS for a given (H,K,TGT,D): `./psph -h H -k K -t TGT -d D -i 0:0` prints "split depth D: N work items".
  Item generation runs single-threaded on every machine before its range starts; it is instantaneous
  except for k=4 at depth 3 (see job 2).
* n(15,7) = A053346(15): the h=14 basis 1 12 52 225 546 3033 5464 has 15-range 29939 (certain lower bound);
  expected 1300-38000 core-hours — only after the jobs above.
* `-p 300` prints progress with an ETA every 5 minutes to the chunk's .err file.
* Memory per thread is about (k-1) x TGT bytes (x2 for psph16): negligible except for k=4 h=303
  (3 x 71 MB x 2 = 430 MB per thread, 41 GB for 96 threads — use fewer threads if RAM is short, e.g. -j 48).
* Do not mix item ranges from different D or different TGT in one logs/TAG directory.
